local gene = {
    ----hunt----
    enemyHealth = ,
    enemyDistance = ,
    isUnderTower = ,
    weDisabled = ,
    eUnderTower = ,
    enemyNear = ,
    EnemyPowerful = ,
    EnemyWeak = ,
    enemyNearAndNotLevel = ,
    EnemyDisabled = ,
    punchBack = ,
    allyInFight = ,

    ----retreat----
    willEnemyTowerTargetMe = ,
    isEnemyTowerTargetingMeNoAlly = ,
    hasPassiveEnemyNearby = ,
    hasAggressiveEnemyNearby = ,
    hasEnemyCreepsNearby = ,
    hardRetreat = ,
    enemyRetreat = ,
    FountainMana = ,
    AreThereDangerPings = ,

    ----farm----
    creepsAround = ,
    calcEnemyCreepHealth = ,
    calcEnemyCreepDist = ,
    enemyNotLevel = ,
    alone =
}

return gene