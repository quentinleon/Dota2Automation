local module = require(GetScriptDirectory().."/helpers")

local Items = {

	"item_stout_shield",

	----phase boots----
	-- "item_boots",
	-- "item_blades_of_attack",
	-- "item_chainmail",

	-- ----blink----
	-- "item_blink",

	-- ----skull basher----
	-- "item_belt_of_strength",
	-- "item_mithril_hammer",
	-- "item_recipe_basher",

	-- ----black king bar----
	-- "item_mithril_hammer",
	-- "item_ogre_axe",
	-- "item_recipe_black_king_bar",

	-- ----vanguard/abyssal----
	-- "item_ring_of_health",
	-- "item_vitality_booster",
	-- "item_recipe_abyssal_blade",

	-- ----vlads----
	-- "item_lifesteal",
	-- "item_quarterstaff",
	-- "item_recipe_mask_of_madness",

	-- ----ag's scepter----
	-- "item_point_booster",
	-- "item_staff_of_wizardry",
	-- "item_ogre_axe",
	-- "item_blade_of_alacrity"

}

return Items